# My Awesome Web App
- Deployed on AWS Elastic Beanstalk
- URL: http://my-awesome-web-app-env.eba-xyz.us-east-1.elasticbeanstalk.com
- Tech: Node.js, EJS
- Status: Working with CI/CD